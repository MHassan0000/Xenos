#include <bits/kd.h>
